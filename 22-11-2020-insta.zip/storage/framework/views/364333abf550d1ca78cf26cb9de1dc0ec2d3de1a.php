<?php $__env->startSection('content'); ?>
<div class="container">
    <?php if(session()->has('message')): ?>
        <div class="alert alert-success alert-dismissible fade show">
            <button type="button" class="close" data-dismiss="alert">&times;</button>
            <?php echo e(session()->get('message')); ?>

        </div>
    <?php endif; ?>
    <div class="row">
        <div class="col-4 col-xs-6 col-sm-5 col-md-2 offset-md-2">
            <img src="<?php echo e($user->profile->profileImage()); ?>" style="max-height: 150px;" class="rounded-circle img-fluid">
        </div>
        <div class="col-8 col-xs-6 col-sm-7 col-md-8">
            <div class="d-flex justify-content-between align-items-baseline">
                <div class="d-flex align-items-center pb-2">
                    <div class="h4"><?php echo e($user->username); ?></div>
                    <?php if(auth()->user() == NULL): ?>
                        <follow-button user-id="<?php echo e($user->id); ?>" follow="<?php echo e($follow); ?>"></follow-button>
                    <?php else: ?>
                        <?php if(auth()->user()->id != $user->id): ?>
                            <follow-button user-id="<?php echo e($user->id); ?>" follow="<?php echo e($follow); ?>"></follow-button>
                        <?php endif; ?>
                    <?php endif; ?>
                </div>
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('update', $user->profile)): ?>
                    <a class="btn btn-outline-primary" href="p/create">Add Post</a>
                <?php endif; ?>
            </div>
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('update', $user->profile)): ?>
                <div class="pb-1">
                    <a class="text-primary" href="<?php echo e($user->username); ?>/edit">Edit Profile</a>
                </div>
            <?php endif; ?>
            <div class="d-flex">
                <div class="pr-4"><strong><?php echo e($user->posts->count()); ?></strong> posts</div>
                <div class="pr-4" data-toggle="modal" data-target="#followers"><strong><?php echo e($user->profile->followers->count()); ?></strong> followers</div>
                <div class="pr-4" data-toggle="modal" data-target="#following"><strong><?php echo e($user->following->count()); ?></strong> following</div>

                <!-- Following Modal Start -->
                <div class="modal fade" id="following">
                    <div class="modal-dialog modal-dialog-scrollable modal-sm">
                        <div class="modal-content">
                            <!-- Modal Header -->
                            <div class="modal-header">
                                <h5 class="modal-title align-items-center">Following</h5>
                                <button type="button" class="close" data-dismiss="modal">×</button>
                            </div>
                            <!-- Modal body -->
                            <div class="modal-body">
                                <?php $__currentLoopData = $user->following; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $following): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div>
                                        <a href="<?php echo e($following->user->username); ?>">
                                            <div class="d-flex align-items-baseline p-0">
                                                <div class="pr-2">
                                                    <img src="<?php echo e($following->profileImage()); ?>" style="max-height: 40px;" class="rounded-circle img-fluid">
                                                </div>
                                                <div class="text-dark font-weight-bold"><?php echo e($following->user->username); ?></div>
                                            </div>
                                        </a>
                                        <div class="dropdown-divider"></div>
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- Following Modal End -->
                <!-- Followers Modal Start -->
                <div class="modal fade" id="followers">
                    <div class="modal-dialog modal-dialog-scrollable modal-sm">
                        <div class="modal-content">
                            <!-- Modal Header -->
                            <div class="modal-header">
                                <h5 class="modal-title align-items-center">Followers</h5>
                                <button type="button" class="close" data-dismiss="modal">×</button>
                            </div>
                            <!-- Modal body -->
                            <div class="modal-body">
                                <?php $__currentLoopData = $user->profile->followers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $follower): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div>
                                        <a href="<?php echo e($follower->username); ?>">
                                            <div class="d-flex align-items-baseline p-0">
                                                <div class="pr-2">
                                                    <img src="<?php echo e($follower->profile->profileImage()); ?>" style="max-height: 40px;" class="rounded-circle img-fluid">
                                                </div>
                                                <div class="text-dark font-weight-bold"><?php echo e($follower->username); ?></div>
                                            </div>
                                        </a>
                                        <div class="dropdown-divider"></div>
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- Followers Modal End -->

            </div>
            <div class="pt-4"><strong><?php echo e($user->profile->title); ?></strong></div>
            <div class="pt-2"><?php echo e($user->profile->description); ?></div>
            <div><a href="#"><?php echo e($user->profile->url); ?></a></div>
        </div>
    </div>
    <div class="row p-2">
        <?php $__currentLoopData = $user->posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-4">
                <a href="p/<?php echo e($post->id); ?>">
                    <img src="storage/<?php echo e($post->image); ?>" class="w-100 pt-4">
                </a>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\insta\resources\views/profile/index.blade.php ENDPATH**/ ?>