<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row">
                <div class="col-12 col-sm-8 offset-sm-2 col-md-6 offset-md-3">
                    <div>
                        <div class="d-flex align-items-center">
                            <div class="pr-3">
                                <img src="<?php echo e($post->user->profile->profileImage()); ?>" style="max-height: 45px; max-width: 45px" class="rounded-circle img-fluid">
                            </div>
                            <div>
                                <div class="font-weight-bold ">
                                    <a href="<?php echo e(URL::to('/')); ?>/<?php echo e($post->user->username); ?>"><span class="text-dark"><?php echo e($post->user->username); ?></span> </a>
                                </div>
                            </div>
                            <div>
                                <?php if(auth()->user() == NULL): ?>
                                    <follow-button user-id="<?php echo e($post->user->id); ?>" follow="<?php echo e($follow); ?>"></follow-button>
                                <?php else: ?>
                                    <?php if(auth()->user()->id != $post->user->id): ?>
                                        <follow-button user-id="<?php echo e($post->user->id); ?>" follow="<?php echo e($follow); ?>"></follow-button>
                                    <?php endif; ?>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                    <hr>
                    <p>
                        <span class="font-weight-bold">
                            <a href="<?php echo e(URL::to('/')); ?>/<?php echo e($post->user->username); ?>">
                                <span class="text-dark"><?php echo e($post->user->username); ?> </span>
                            </a>
                        </span>
                        <?php echo e($post->caption); ?>

                    </p>
                </div>
        </div>
        <div class="row">
            <div class="col-12 col-sm-8 offset-sm-2  col-md-6 offset-md-3">
                <img src="<?php echo e(asset('storage/' . $post->image)); ?>" class="w-100">
            </div>
        </div>
        <div class="row">
            <div class="col-12 col-sm-8 offset-sm-2 col-md-6 offset-md-3 pt-2">
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('update', $post->user->profile)): ?>
                    <hr>
                        <div class="d-flex justify-content-start">
                            <div>
                                <a href="<?php echo e($post->id); ?>/edit" class="btn btn-sm btn-outline-dark mr-2">Edit</a>
                            </div>
                            <div>
                                <form action="<?php echo e($post->id); ?>" method="POST">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('DELETE'); ?>
                                    <button class="btn btn-sm btn-outline-danger mr-2">Delete</button>
                                </form>
                            </div>
                        </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>




































<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\insta\resources\views/post/show.blade.php ENDPATH**/ ?>